<div class="panel">
    <div class="tab-title clearfix">
        <h4><?php echo lang('description'); ?></h4>
    </div>
    <div class="p15">
        <?php echo nl2br(link_it($project_info->description)); ?>
    </div>
</div>