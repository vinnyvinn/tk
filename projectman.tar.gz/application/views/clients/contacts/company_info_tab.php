<div class="tab-content">
    <?php echo form_open(get_uri("clients/save"), array("id" => "company-form", "class" => "general-form dashed-row white", "role" => "form")); ?>
    <div class="panel">
        <div class="panel-default panel-heading">
            <h4> <?php echo lang('company'); ?></h4>
        </div>
        <div class="panel-body">
            <?php $this->load->view("clients/client_form_fields"); ?>
        </div>
        <div class="panel-footer">
            <button type="submit" class="btn btn-primary"><span class="fa fa-check-circle"></span> <?php echo lang('save'); ?></button>
        </div>
    </div>
    <?php echo form_close(); ?>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $("#company-form").appForm({
            isModal: false,
            onSuccess: function(result) {
                appAlert.success(result.message, {duration: 10000});
                setTimeout(function() {
                    location.reload();
                }, 500);
            }
        });
    });
</script>