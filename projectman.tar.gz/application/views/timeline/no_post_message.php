<div class="text-center p30">
    <i class="fa fa-list-alt" style="font-size: 100px;"></i> <br />
    <?php
    echo lang("no_posts_to_show");
    ?>
</div>
