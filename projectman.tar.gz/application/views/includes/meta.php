<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge" >
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="fairsketch">
<link rel="icon" href="<?php echo get_file_uri("assets/images/favicon.png"); ?>" />

<title><?php echo get_setting('app_title'); ?></title>