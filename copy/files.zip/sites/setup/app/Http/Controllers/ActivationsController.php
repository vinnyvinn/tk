<?php

namespace App\Http\Controllers;

use App\Activation;
use App\Events\UserRegistered;
use App\User;
use Event;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ActivationsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response|\Illuminate\View\View
     */
    public function index()
    {
        return view('welcome.activation')
            ->with('title', 'Verify your email')
            ->with('message', 'Please verify your email address to get started with TeamKazi');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Http\Response|\Illuminate\Routing\Redirector
     */
    public function store(Request $request)
    {
        $activationData = $request->all();
        $activationData['key'] = Str::random(32);
        $activationData['is_active'] = 0;

        $activation = Activation::firstOrNew([
            'email' => $activationData['email'],
        ]);

        if ($activation->is_active) {
            if (User::where('email', $activation->email)->exists()) {
                return redirect('/login')->withErrors([
                    'message' => 'The provided email has already been registered. Please log in to continue.'
                ]);
            }

            return redirect()->route('email.show', $activation->key);
        }

        $activation->fill($activationData)->save();

        Event::fire(new UserRegistered($activation));

        return redirect()->route('email.index');
    }


    /**
     * Display the specified resource.
     *
     * @param Request $request
     * @param         $key
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\RedirectResponse|\Illuminate\Http\Response|\Illuminate\Routing\Redirector|\Illuminate\View\View
     *
     */
    public function show(Request $request, $key)
    {
        $activation = Activation::where('key', $key)->firstOrFail();

        if ($activation->is_active) {
            if (User::where('email', $activation->email)->exists()) {
                return redirect('/login')->withErrors([
                    'message' => 'The provided email has already been registered. Please log in to continue.'
                ]);
            }
        }

        return view('auth.register')->with('activation', $activation);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Activation $activations
     *
*@return \Illuminate\Http\Response
     */
    public function edit(Activation $activations)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\Activation          $activations
     *
*@return \Illuminate\Http\Response
     */
    public function update(Request $request, Activation $activations)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Activation $activations
     *
*@return \Illuminate\Http\Response
     */
    public function destroy(Activation $activations)
    {
        //
    }
}
