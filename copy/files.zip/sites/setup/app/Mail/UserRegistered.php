<?php

namespace App\Mail;

use App\Activation;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class UserRegistered extends Mailable
{
    use Queueable, SerializesModels;
    /**
     * @var Activation
     */
    public $activation;

    public $url;

    /**
     * Create a new message instance.
     *
     * @param Activation $activation
     */
    public function __construct(Activation $activation)
    {
        $this->activation = $activation;
        $this->url = route('email.show', $activation->key);
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->subject('Complete your TeamKazi sign up')
            ->markdown('emails.user.registered');
    }
}
