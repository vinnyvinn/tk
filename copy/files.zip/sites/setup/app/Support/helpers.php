<?php

function flash($title, $message, $status = 'info')
{
    session('flash_title', $title);
    session('flash_message', $message);
    session('flash_status', $status);
}
