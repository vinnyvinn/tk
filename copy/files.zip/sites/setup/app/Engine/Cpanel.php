<?php

namespace App\Engine;

use Gufy\CpanelPhp\Cpanel as CpanelCore;

class Cpanel
{
    const
        CPANEL_API_1 = 1,
        CPANEL_API_2 = 2,
        UAPI = 3;

    public static function initialize()
    {
        return new CpanelCore([
            'host'        =>  env('CPANEL_HOST') . ':2083',
            'username'    =>  env('CPANEL_USERNAME'),
            'auth_type'   =>  'password',
            'password'    =>  env('CPANEL_PASSWORD'),
        ]);
    }

    public static function createSubdomain($rootDomain, $subDomain, $dir, $engine = null)
    {
        if (! $engine) {
            $engine = self::initialize();
        }

        $response = $engine
            ->execute_action(self::CPANEL_API_2, 'SubDomain', 'addsubdomain', 'cpanel_username', [
                'domain'        => $subDomain,
                'rootdomain'    => $rootDomain,
                'dir'           => $dir,
                'disallowdot'   => '1',
            ]);

        return $response;
    }

    public static function createDatabase($database, $engine = null)
    {
        if (! $engine) {
            $engine = self::initialize();
        }

        $response = $engine->execute_action(self::UAPI, 'Mysql', 'create_database', 'cpanel_username', [
            'name' => $database
        ]);

        return $response;
    }

    public static function createDBUser($username, $password, $database, $engine = null)
    {
        if (! $engine) {
            $engine = self::initialize();
        }

        $engine->execute_action(self::UAPI, 'Mysql', 'create_user', 'cpanel_username', [
                'name' => $username,
                'password' => $password
            ]);

        $engine->execute_action(self::UAPI, 'Mysql', 'set_privileges_on_database', 'cpanel_username', [
                'user' => $username,
                'database' => $database,
                'privileges' => 'ALL PRIVILEGES'
            ]);

        $response = $engine->execute_action(self::UAPI, 'Mysql', 'set_privileges_on_database', 'cpanel_username', [
            'user' => 'teamkazi_base',
            'database' => $database,
            'privileges' => 'ALL PRIVILEGES'
        ]);

        return $response;
    }

}
