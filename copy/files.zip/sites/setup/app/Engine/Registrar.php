<?php

namespace App\Engine;

use App\Company;
use App\User;

class Registrar
{
    protected $user;
    protected $company;
    protected $corePassword;

    public static function configure()
    {
        return new self();
    }

    public function forUser(User $user)
    {
        $this->user = $user;

        return $this;
    }

    public function underCompany(Company $company)
    {
        $this->company = $company;

        return $this;
    }

    public function withCorePassword($password)
    {
        $this->corePassword = $password;

        return $this;
    }

    public function run()
    {
        $commonId = 'teamkazi_a' . $this->company->id;
        $commonPass = self::getPassword();
        $engine = Cpanel::initialize();
        Cpanel::createSubdomain('teamkazi.com', 'a' . $this->company->id, '/public_html', $engine);
        Cpanel::createDatabase($commonId);
        Cpanel::createDBUser($commonId, $commonPass, $commonId, $engine);
        $this->updateDB($commonId, $commonPass);
        $this->updateCompany($commonId, $commonPass);

        return true;
    }

    private function getPassword()
    {
        $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*()_+~":<>?,./|{}[]';
        $pass = []; //remember to declare $pass as an array
        $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
        for ($i = 0; $i < 16; $i++) {
            $n = rand(0, $alphaLength);
            $pass[] = $alphabet[$n];
        }
        return implode($pass); //turn the array into a string
    }

    private function updateCompany($commonId, $password)
    {
        $this->company->update([
            'common' => $commonId,
            'password' => $password
        ]);
    }

    private function updateDB($commonId, $password)
    {
        $connection = (new Connection($commonId, [
            'username' => $commonId,
            'password' => $password,
        ]))->getConnection();

        $queries = file_get_contents(storage_path('core/teamkazi_base.sql'));
        $connection->unprepared($queries);

        $connection->table('users')->where('id', 1)->update([
            'first_name' => $this->user->name,
            'last_name' => '',
            'email' => $this->user->email,
            'password' => md5($this->corePassword)
        ]);

        return true;
    }
}
