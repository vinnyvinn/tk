<?php

namespace App\Engine;

use Config;
use DB;

class Connection
{
    /**
     * The name of the database we're connecting to on the fly.
     *
     * @var string $database
     */
    protected $database;
    /**
     * The on the fly database connection.
     *
     * @var \Illuminate\Database\Connection
     */
    protected $connection;

    /**
     * Create a new on the fly database connection.
     *
     * @param  string $database
     * @param  array $options
     */
    public function __construct($database, $options = null)
    {
        $this->database = $database;
        $defaults = $this->getBaseConnection();
        $defaults['database'] = $database;

        foreach ($defaults as $item => $value) {
            $defaults[$item] = isset($options[$item]) ? $options[$item] : $defaults[$item];
        }

        Config::set("database.connections.$database", $defaults);

        $this->connection = DB::connection($database);
    }

    private function getBaseConnection()
    {
        return [
            'driver' => 'mysql',
            'host' => env('DB_HOST', '127.0.0.1'),
            'port' => env('DB_PORT', '3306'),
            'username' => env('DB_USERNAME', 'forge'),
            'password' => env('DB_PASSWORD', ''),
            'charset' => 'utf8mb4',
            'collation' => 'utf8mb4_unicode_ci',
            'prefix' => '',
            'strict' => true,
            'engine' => null,
        ];
    }

    /**
     * Get the on the fly connection.
     *
     * @return \Illuminate\Database\Connection
     */
    public function getConnection()
    {
        return $this->connection;
    }
}
