<section class="row top_header">
    <div class="container">
        <div class="row">
            <div class="col-sm-6 wc_msg"></div>
            <div class="col-sm-6">
                <ul class="nav nav-pills">
                    <li><a href="tel:+254711408108"><i class="icon-call-out"></i>+254 711 408 108</a></li>
                    <li><a href="mailto:info@teamkazi.com"><i class="icon-envelope"></i>info@teamkazi.com</a></li>
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                    <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</section>
<nav class="navbar navbar-default navbar-static-top fluid_header centered affix-top">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('images/logo.png')); ?>" alt="TeamKazi"></a>
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#main_navigation" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="main_navigation">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li><a href="<?php echo e(url('/')); ?>">Features</a></li>
                <li><a href="<?php echo e(url('/')); ?>">Pricing</a></li>
                <li><a href="<?php echo e(url('/')); ?>">Customers</a></li>
                <li><a href="<?php echo e(url('/')); ?>">Contact</a></li>

                <li class="login-link"><a href="#get-started">Get Started For Free</a></li>
                <li class="login-link"><a href="<?php echo e(route('login', App::getLocale())); ?>">login</a></li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
