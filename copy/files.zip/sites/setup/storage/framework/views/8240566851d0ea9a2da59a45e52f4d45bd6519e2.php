<?php $__env->startComponent('mail::message'); ?>
<div>
    <h2 style="text-align: center">Just one last click!</h2>
</div>

<?php $__env->startComponent('mail::button', ['url' => $url]); ?>
Verify your email address
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
