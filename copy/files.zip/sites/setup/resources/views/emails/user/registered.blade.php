@component('mail::message')
<div>
    <h2 style="text-align: center">Just one last click!</h2>
</div>

@component('mail::button', ['url' => $url])
Verify your email address
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent
