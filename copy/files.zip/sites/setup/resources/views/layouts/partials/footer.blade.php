<section class="row service_tabs_list" id="get-started">
    <div class="row m0 service_tab service_tab3">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="row sectionTitle text-left">
                        <h5 class="text-center"></h5>
                        <h3 class="text-center">GET STARTED FOR FREE</h3>
                    </div>
                </div>
                <div class="col-sm-6 col-sm-offset-3">
                    <form action="{{ url('register/email') }}" method="post">
                        {{ csrf_field() }}
                        <div class="input-group ">
                            <input type="email" name="email" class="form-control" placeholder="name@company.com">
                            <span class="input-group-btn">
                                <input type="submit" class="btn btn-success" value="Get started for free">
                            </span>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<footer class="row">
    <div class="top_footer row m0">
        <div class="container">
            <div class="row m0 quick_contact">
                <ul class="nav nav-pills">
                    <li><a href="tel:+254711408108"><i class="lnr lnr-phone"></i>+254 711 408 108</a></li>
                    <li><a href="mailto:info@teamkazi.com"><i class="lnr lnr-envelope"></i>info@teamkazi.com</a></li>
                    <li><a href="#"><i class="lnr lnr-bubble"></i>chat with us</a></li>
                </ul>
            </div>
            <div class="row shortKnowledge">
                <div class="col-sm-6 about">
                    <h4><a href="{{ url('/') }}"><img src="{{ asset('images/logo.png') }}" alt=""></a></h4>
                    <p>Lorem ipsum dolor sit amet, ectetur adipiscing elit.viverra tellus. Vivamus finibus, quam vitae pulvinar euismod, Lorem ipsum dolor sit amet, ectetur adipiscing elit.ectetur adipiscing elit.viverra tellusivamus finibus, quam vitae pulvinar euismod,</p>
                </div>
                <div class="col-sm-6 product">
                    <h4>Product</h4>
                    <ul class="product_list nav">
                        <li><a href="#">Webhosting</a></li>
                        <li><a href="#">Reseler Hosting</a></li>
                        <li><a href="#">VPS Hosting</a></li>
                        <li><a href="#">Wordpress Hosting</a></li>
                        <li><a href="hosting-dedicated.html">dedicated hosting</a></li>
                        <li><a href="#">Windows Hosting</a></li>
                    </ul>
                </div>
            </div>
            <div class="row beInContact m0">
                <div class="btn-group country_select">
                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="flag"><img src="images/icons/footer/flag.png" alt=""></span>India<i class="lnr lnr-chevron-down"></i>
                    </button>
                    <ul class="dropdown-menu">
                        <li><a href="#">India</a></li>
                        <li><a href="#">Bangladesh</a></li>
                        <li><a href="#">England</a></li>
                        <li><a href="#">Iran</a></li>
                        <li><a href="#">Syria</a></li>
                    </ul>
                </div>
                <div class="social_icos">
                    <ul class="nav">
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-google"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                    </ul>
                </div>
                <div class="subscribe_form">
                    <form action="#" class="form-inline">
                        <div class="form-group">
                            <label>Subscribe<small>Newsletter</small></label>
                            <div class="input-group">
                                <input type="email" class="form-control" placeholder="Email Address">
                                <span class="input-group-addon"><input type="submit" value="Go" class="btn"></span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row m0 copyright_line">
        Copyright &copy; 1999 - 2015 hostpress.com. All Rights Reserved
    </div>
</footer>
