@extends('layouts.app')

@section('content')

    <section class="row slider">
        <div id="home_slider3" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
                <li data-target="#home_slider3" data-slide-to="0" class="active">
                    <img src="{{ asset('images/icons/service/tab/1.png') }}" alt="Core EcoSystem" class="icon">
                    Core EcoSystem
                </li>
                <li data-target="#home_slider3" data-slide-to="1">
                    <img src="{{ asset('images/icons/service/tab/2.png') }}" alt="Global Access" class="icon">
                    Global Access
                </li>
                <li data-target="#home_slider3" data-slide-to="2">
                    <img src="{{ asset('images/icons/service/tab/3.png') }}" alt="Resource Management" class="icon">
                    Resource Management
                </li>
                <li data-target="#home_slider3" data-slide-to="3">
                    <img src="images/icons/service/tab/4.png" alt="" class="icon">
                    Domain Hosting
                </li>
            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner" role="listbox">
                <div class="item active">
                    <div class="carousel-caption">
                        <div class="container">
                            <div class="row">
                                <div class="media">
                                    <div class="media-left media-middle">
                                        <img src="{{ asset('images/slider/2-2/1.png') }}" alt="TeamKazi">
                                    </div>
                                    <div class="media-body">
                                        <h4>Core Ecosystem</h4>
                                        <h2>PROJECT<br class="hidden-xs"> NETWORKING</h2>
                                        <p>Keep all links interconnected and get up to date project information... </p>
                                        <a href="{{ url('/features') }}" class="btn btn-primary">know more</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="carousel-caption">
                        <div class="container">
                            <div class="row">
                                <div class="media">
                                    <div class="media-left media-middle">
                                        <img src="{{ asset('images/slider/2-2/2.png') }}" alt="TeamKazi">
                                    </div>
                                    <div class="media-body">
                                        <h4>Global Access</h4>
                                        <h2>Access<br class="hidden-xs"> anywhere</h2>
                                        <p>No matter your location, access everything you need at the click of a button...</p>
                                        <a href="{{ url('/features') }}" class="btn btn-primary">know more</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="carousel-caption">
                        <div class="container">
                            <div class="row">
                                <div class="media">
                                    <div class="media-left media-middle">
                                        <img src="{{ asset('images/slider/2-2/3.png') }}" alt="TeamKazi">
                                    </div>
                                    <div class="media-body">
                                        <h4>Accountability</h4>
                                        <h2>Resource<br class="hidden-xs"> Management</h2>
                                        <p>Get the ultimate team productivity report based on the hourly rates... </p>
                                        <a href="{{ url('/features') }}" class="btn btn-primary">know more</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="carousel-caption">
                        <div class="container">
                            <div class="row">
                                <div class="media">
                                    <div class="media-left media-middle">
                                        <img src="{{ asset('images/slider/2-2/4.png') }}" alt="">
                                    </div>
                                    <div class="media-body">
                                        <h4>secure with notifications</h4>
                                        <h2>Get notified<br class="hidden-xs"> on the go</h2>
                                        <p>Secured using SSL, receive instant notifications on task creation, modification, when a new comment has been posted...</p>
                                        <a href="{{ url('/features') }}" class="btn btn-primary">know more</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Controls -->
            <a class="left carousel-control" href="#home_slider3" role="button" data-slide="prev">
                <span class='lnr lnr-chevron-left'></span>
            </a>
            <a class="right carousel-control" href="#home_slider3" role="button" data-slide="next">
                <span class='lnr lnr-chevron-right'></span>
            </a>
        </div>
    </section>


    <section class="row pricing">
        <div class="container">
            <div class="row sectionTitle">
                <h5>our package &amp;</h5>
                <h2>pricing plan</h2>
            </div>
            <div class="owl-carousel pricing_plan">
                <div class="item">
                    <div class="row m0 plan">
                        <div class="price row m0">
                            <span class="currencyType">$</span>
                            <span class="amount">19</span>
                            <small>/mo</small>
                        </div>
                        <div class="serviceType row m0">
                            <h4>dedicated hosting</h4>
                        </div>
                        <p>Lorem ipsum dolor sit amet, ectetur adipiscing elit.</p>
                        <a href="#" class="btn btn-primary">Get Started</a>
                    </div>
                </div>
                <div class="item">
                    <div class="row m0 plan">
                        <div class="price row m0">
                            <span class="currencyType">$</span>
                            <span class="amount">29</span>
                            <small>/mo</small>
                        </div>
                        <div class="serviceType row m0">
                            <h4>VPS hosting</h4>
                        </div>
                        <p>Lorem ipsum dolor sit amet, ectetur adipiscing elit.</p>
                        <a href="#" class="btn btn-primary">Get Started</a>
                    </div>
                </div>
                <div class="item">
                    <div class="row m0 plan">
                        <div class="price row m0">
                            <span class="currencyType">$</span>
                            <span class="amount">39</span>
                            <small>/mo</small>
                        </div>
                        <div class="serviceType row m0">
                            <h4>shared hosting</h4>
                        </div>
                        <p>Lorem ipsum dolor sit amet, ectetur adipiscing elit.</p>
                        <a href="#" class="btn btn-primary">Get Started</a>
                    </div>
                </div>
                <div class="item">
                    <div class="row m0 plan">
                        <div class="price row m0">
                            <span class="currencyType">$</span>
                            <span class="amount">49</span>
                            <small>/mo</small>
                        </div>
                        <div class="serviceType row m0">
                            <h4>reseller hosting</h4>
                        </div>
                        <p>Lorem ipsum dolor sit amet, ectetur adipiscing elit.</p>
                        <a href="#" class="btn btn-primary">Get Started</a>
                    </div>
                </div>
            </div>
            <div class="row pricing_nav">
                <div class="col-sm-4 col-sm-offset-4">
                    <div id="pricing_nav" class="row m0"></div>
                </div>
            </div>
        </div>
    </section>
    <section class="row pricing_bottom"></section>
    <section class="row facts">
        <div class="container">
            <div class="row">
                <div class="col-sm-3 fact"><strong class="counter">5000</strong>Happy clients</div>
                <div class="col-sm-3 fact"><strong class="counter">3000</strong>servers</div>
                <div class="col-sm-3 fact"><strong class="counter">200</strong>dedicated staff</div>
                <div class="col-sm-3 fact"><strong class="counter">20</strong>awards won</div>
            </div>
        </div>
    </section>
    <section class="row why_choose home2">
        <div class="container">
            <div class="row sectionTitle">
                <h5>Why Choose</h5>
                <h2>hostpress</h2>
            </div>
            <div class="row">
                <div class="col-sm-4 cause2choose">
                    <div class="media">
                        <div class="media-left"><a href="#"><img src="images/icons/cause2choose/1.png" alt=""></a></div>
                        <div class="media-body">
                            <h4>Free Data Analysis</h4>
                            <p>Lorem ipsum dolor sit amet, ectetur adipiscing elit. Nullam eget</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 cause2choose">
                    <div class="media">
                        <div class="media-left"><a href="#"><img src="images/icons/cause2choose/2.png" alt=""></a></div>
                        <div class="media-body">
                            <h4>security</h4>
                            <p>Lorem ipsum dolor sit amet, ectetur adipiscing elit. Nullam eget</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 cause2choose">
                    <div class="media">
                        <div class="media-left"><a href="#"><img src="images/icons/cause2choose/3.png" alt=""></a></div>
                        <div class="media-body">
                            <h4>free domain transfer</h4>
                            <p>Lorem ipsum dolor sit amet, ectetur adipiscing elit. Nullam eget</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 cause2choose">
                    <div class="media">
                        <div class="media-left"><a href="#"><img src="images/icons/cause2choose/4.png" alt=""></a></div>
                        <div class="media-body">
                            <h4>Data on cloudfront</h4>
                            <p>Lorem ipsum dolor sit amet, ectetur adipiscing elit. Nullam eget</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 cause2choose">
                    <div class="media">
                        <div class="media-left"><a href="#"><img src="images/icons/cause2choose/5.png" alt=""></a></div>
                        <div class="media-body">
                            <h4>technical support</h4>
                            <p>Lorem ipsum dolor sit amet, ectetur adipiscing elit. Nullam eget</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 cause2choose">
                    <div class="media">
                        <div class="media-left"><a href="#"><img src="images/icons/cause2choose/6.png" alt=""></a></div>
                        <div class="media-body">
                            <h4>free website optimization</h4>
                            <p>Lorem ipsum dolor sit amet, ectetur adipiscing elit. Nullam eget</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="row service_tabs_list">
        <div class="row m0 service_tab service_tab1">
            <div class="container">
                <div class="row">
                    <div class="col-sm-5 ico_price">
                        <div class="row m0">
                            <div class="ico">
                                <img src="images/icons/service/tab/5.png" alt="">
                            </div>
                            <div class="row m0 rent"><span>$</span>29<small>monthly</small></div>
                        </div>
                    </div>
                    <div class="col-sm-7 content">
                        <h4>hosting</h4>
                        <h3 class="title">dedicated</h3>
                        <p>Lorem ipsum dolor sit amet, ectetur adipiscing elit. Nullam eget  dolor sit amet, ecc.</p>
                        <ul class="hostpressUnList">
                            <li>Fully Managed Dedicated Server</li>
                            <li>Windows &amp; Linux</li>
                            <li>Complate Control with Root access</li>
                            <li>Dedicated Bandwidth</li>
                        </ul>
                        <a href="#" class="btn btn-primary">know more</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row m0 service_tab service_tab2">
            <div class="container">
                <div class="row">
                    <div class="col-sm-5 ico_price">
                        <div class="row m0">
                            <div class="ico">
                                <img src="images/icons/service/tab/6.png" alt="">
                            </div>
                            <div class="row m0 rent"><span>$</span>29<small>monthly</small></div>
                        </div>
                    </div>
                    <div class="col-sm-7 content">
                        <h4>hosting</h4>
                        <h3 class="title">shared</h3>
                        <p>Lorem ipsum dolor sit amet, ectetur adipiscing elit. Nullam eget  dolor sit amet, ecc.</p>
                        <ul class="hostpressUnList">
                            <li>Fully Managed Dedicated Server</li>
                            <li>Windows &amp; Linux</li>
                            <li>Complate Control with Root access</li>
                            <li>Dedicated Bandwidth</li>
                        </ul>
                        <a href="#" class="btn btn-primary">know more</a>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <section class="row testi_news">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <div class="row sectionTitle text-left">
                        <h5>customers</h5>
                        <h3>testimonial</h3>
                    </div>
                    <div class="testimonial_slider owl-carousel">
                        <div class="item">
                            <div class="row slide m0">
                                <div class="fleft client_img"><img src="images/testimonial/1.png" alt=""></div>
                                <div class="fleft content">
                                    <div class="counter">01</div>
                                    <div class="row m0 quote">
                                        <p>Lorem ipsum dolor sit amet, ectetur adipiscing elit. viverra tellus.</p>
                                        <p>Vivamus finibus, quam vitae pulvinar euismod, Lorem ipsum dolor sit amet, ectetur adipiscing elit.</p>
                                    </div>
                                    <h5 class="client_name">John Doe</h5>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="row slide slide2 m0">
                                <div class="fleft client_img"><img src="images/testimonial/2.png" alt=""></div>
                                <div class="fleft content">
                                    <div class="counter">02</div>
                                    <div class="row m0 quote">
                                        <p>Lorem ipsum dolor sit amet, ectetur adipiscing elit. viverra tellus.</p>
                                        <p>Vivamus finibus, quam vitae pulvinar euismod, Lorem ipsum dolor sit amet, ectetur adipiscing elit.</p>
                                    </div>
                                    <h5 class="client_name">Baby Doe</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="row sectionTitle text-left">
                        <h5>Let's</h5>
                        <h3>Connect</h3>
                    </div>
                    <div class="contactForm row m0">
                        <form action="contact_process.php" class="row m0" id="contactForm">
                            <input type="text" class="form-control" placeholder="Name" name="name" id="name">
                            <input type="email" class="form-control" placeholder="Email" name="email" id="email">
                            <textarea class="form-control" placeholder="Message" name="message" id="message"></textarea>
                            <input type="submit" value="send message" class="btn btn-primary">
                        </form>
                        <div id="success">Your message successfully sent!</div>
                        <div id="error">Sorry, there must be something wrong!! Please try again.</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

@endsection