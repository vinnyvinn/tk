@extends('layouts.app')

@section('content')
    <section class="row why_choose home2">
        <div class="container">
            <div class="row sectionTitle">
                <h5><img src="{{ asset('images/icons/feature/4.png') }}" alt=""></h5>
                <h2>{{ $title }}</h2>
            </div>
            <div class="row">
                <div class="col-sm-12 cause2choose">
                    <div class="media">
                        <div class="media-body">
                            <p class="text-center" style="font-size: 24px">{{ $message }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection