@extends('layouts.app')

@section('content')
    <section class="row why_choose home2">
        <div class="container">
            <div class="col-md-6 col-md-offset-3">
                <div class="panel panel-success">
                    <div class="panel-body">
                        <br>
                        <br>
                        <div class="row sectionTitle">
                            <img src="{{ asset('images/logo.png') }}" alt="TeamKazi">
                            <br>
                            <br>
                            <h5>Please complete your registration</h5>
                        </div>

                        <div class="row">
                            <div class="col-sm-10 col-sm-offset-1">
                                <form role="form" method="POST" action="{{ route('register') }}">
                                    {{ csrf_field() }}
                                    <input type="hidden" name="key" value="{{ $activation->key }}">

                                    <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                                        <label for="name" class="control-label">Full Name</label>

                                        <div class="">
                                            <input id="name" type="text" class="form-control" name="name" value="{{ old('name') }}" required autofocus placeholder="John Doe">

                                            @if ($errors->has('name'))
                                                <span class="help-block">
                                                <strong>{{ $errors->first('name') }}</strong>
                                            </span>
                                            @endif
                                        </div>
                                    </div>


                                    <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                                        <label for="name" class="control-label">Organization</label>

                                        <div class="">
                                            <input id="organization" type="text" class="form-control" name="organization" value="{{ old('organization') }}" required placeholder="John Doe Limited">

                                            @if ($errors->has('organization'))
                                                <span class="help-block">
                                                <strong>{{ $errors->first('organization') }}</strong>
                                            </span>
                                            @endif
                                        </div>
                                    </div>

                                    <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                                        <label for="email" class="control-label">E-Mail Address</label>

                                        <div class="">
                                            <input readonly id="email" type="email" class="form-control" name="email" value="{{ $activation->email or old('email') }}" required>

                                            @if ($errors->has('email'))
                                                <span class="help-block">
                                                <strong>{{ $errors->first('email') }}</strong>
                                            </span>
                                            @endif
                                        </div>
                                    </div>

                                    <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                                        <label for="password" class="control-label">Password</label>

                                        <div class="">
                                            <input id="password" type="password" class="form-control" name="password" required placeholder="Hoh32^*23!19Bu">

                                            @if ($errors->has('password'))
                                                <span class="help-block">
                                                <strong>{{ $errors->first('password') }}</strong>
                                            </span>
                                            @endif
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="password-confirm" class="control-label">Confirm Password</label>

                                        <div class="">
                                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required placeholder="Hoh32^*23!19Bu">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary btn-block">
                                            Complete Registration
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
