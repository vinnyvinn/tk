@extends('layouts.app')

@section('content')

<section class="row 404_content">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <div class="row m0 error_mark">
                    <img src="{{ asset('images/404.png') }}" alt="">
                    <h4>page not found</h4>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="row m0 error_msg">
                    <h1>opppps... Sorry</h1>
                    <p>Sorry, but we can’t seem to find the page you are looking for.</p>
                    <a href="{{ url('/') }}" class="btn btn-primary"><i class="fa fa-arrow-left"></i>go to our homepage</a>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection