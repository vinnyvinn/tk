Upgrade note:

Since we have custom language defination and we are not using the codeigniter's system lanuguage,
Set the language = english for all lib files. 


