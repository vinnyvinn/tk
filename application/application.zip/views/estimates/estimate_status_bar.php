<div class="panel panel-default  p15 no-border m0">
    <span><?php echo lang("status") . ": " . $estimate_status_label; ?></span>
</div>