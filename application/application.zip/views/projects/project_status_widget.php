<div class="box">
    <div class="box-content widget-container b-r">
        <div class="panel-body ">
            <h1 class=""><?php echo $project_open; ?></h1>
            <span class="text-off uppercase"><?php echo lang("open_projects"); ?></span>
        </div>
    </div>
    <div class="box-content widget-container ">
        <div class="panel-body ">
            <h1><?php echo $project_completed; ?></h1>
            <span class="text-off uppercase"><?php echo lang("projects_completed"); ?></span>
        </div>
    </div>
</div>